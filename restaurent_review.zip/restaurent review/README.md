## PROJECT: Restaurent Reviews ##

## Project Overview: ##
 For this project I have converted a  static webpage to a mobile-ready web application.

## stage 1 ##
 In Stage 1, I converted a static design that lacks accessibility into  the design to be responsive on different sized displays and accessible for screen reader use.I added a service worker to begin the process of creating a seamless offline experience for users.

## Specifications ##

You have been provided the code for a restaurant reviews website. I updated the code to maintain the  functionality. It includes standard accessibility features, and it works offline at all.


## Mapbox ##
 [Mapbox](https://www.mapbox.com/).

## ES6 ##
Most of the code in this project has been written to the ES6 JavaScript specification for compatibility with modern web browsers and future-proofing JavaScript code. 

## how to run ##
open terminal.
Command to this project. 
run npm install to install project dependencies.
With your server running, visit the site: http://localhost:8000 and explore some restaurants.
In Chrome you can open the Console, go to Application / Service Workers, and then check the Offline option to see offline behavior.

## Offline Availability ##
The site uses a service worker to cache responses to requests for site assets. Visited pages are rendered when there is no network access.

## Site elements defined semantically ##
Elements on the page use the appropriate semantic elements. For those elements in which a semantic element is not available, appropriate ARIA roles are defined.